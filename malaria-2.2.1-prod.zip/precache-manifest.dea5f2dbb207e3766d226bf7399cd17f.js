self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a8b4f36676f9f29d691ba3f143eba1e1",
    "url": "./index.html"
  },
  {
    "revision": "73c2ae4abc252b119144",
    "url": "./static/css/2.6639d161.chunk.css"
  },
  {
    "revision": "a53ea8c9b43a335076b1",
    "url": "./static/css/main.9e698828.chunk.css"
  },
  {
    "revision": "73c2ae4abc252b119144",
    "url": "./static/js/2.04907b94.chunk.js"
  },
  {
    "revision": "a53ea8c9b43a335076b1",
    "url": "./static/js/main.7a309c35.chunk.js"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.d653cc00.js"
  },
  {
    "revision": "d6eed632a2f69204631dbdfb32bb9a3e",
    "url": "./static/media/background.d6eed632.jpeg"
  },
  {
    "revision": "16d59158ad4c01944ba1ba4d76bc3fa2",
    "url": "./static/media/diagnosis.16d59158.png"
  },
  {
    "revision": "21dba5ca41c01a06a379b3ad6519fe9a",
    "url": "./static/media/diagnosis.21dba5ca.svg"
  },
  {
    "revision": "fde7ec03780e2daf99b48bb2311d80a2",
    "url": "./static/media/invasive-base.fde7ec03.svg"
  },
  {
    "revision": "8967bd4ac93c2ef8a48a6e6fa49d55f8",
    "url": "./static/media/invasive.8967bd4a.jpg"
  },
  {
    "revision": "a9a86777f8c20b6c53ceaf3c0d80719e",
    "url": "./static/media/invasive.a9a86777.svg"
  },
  {
    "revision": "1d415bd6c2159685853e71a3ca558853",
    "url": "./static/media/prevention.1d415bd6.png"
  },
  {
    "revision": "61c4317d29625f4f116b955b3c1c16db",
    "url": "./static/media/prevention.61c4317d.svg"
  },
  {
    "revision": "3114271d15e2faf5a2a15aea7e820862",
    "url": "./static/media/treatment.3114271d.png"
  },
  {
    "revision": "c7823e562241018d1c2c17408b909180",
    "url": "./static/media/treatment.c7823e56.svg"
  },
  {
    "revision": "75ce29ef2dd8a8b13cc6485e0f2f9f60",
    "url": "./static/media/who-logo-blue.75ce29ef.svg"
  },
  {
    "revision": "d633057e18a58aa580b8e52df0256d75",
    "url": "./static/media/who-logo-blue.d633057e.png"
  }
]);